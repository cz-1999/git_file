/*

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "ClientData.h"
using namespace std;

int main()
{
    int accountNumber;
    string lastName;
    string firstName;
    double balance;


    ofstream outCreadit("credit.txt",ios::in|ios::out|ios::binary);

    if(!outCreadit)
    {
        cerr<<"File could not be opened."<<endl;
        exit(EXIT_FAILURE);
    }
    ClientData client;

    cout<<"Enter account number (1 to 100,0 to end input)\n?";
    cin>>accountNumber;

    while(accountNumber>0&&accountNumber<=10)
    {
        cout<<"Enter lastname,firstname,balance\n?";
        cin>>lastName;
        cin>>firstName;
        cin>>balance;

        client.setAccountNumber(accountNumber);
        client.setFirstName(firstName);
        client.setLastName(lastName);
        client.setBalance(balance);

        outCreadit.seekp((client.getAccountNumber()-1)*sizeof(ClientData));
        outCreadit.write(reinterpret_cast<const char *>(&client),sizeof(ClientData));

        cout<<"Enter account number\n";
        cin>>accountNumber;

    }

}

*/
