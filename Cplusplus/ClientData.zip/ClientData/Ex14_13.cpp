#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include "ClientData.h"
using namespace std;
void outputLine(ostream&,const ClientData &);

int main()
{
    ifstream inCredit("credit.txt",ios::in|ios::binary);

    if(!inCredit)
    {
        cerr<<"File could not be opened."<<endl;
        exit(EXIT_FAILURE);
    }

    cout<<left<<setw(10)<<"Acount"<<setw(16)<<"Last Name"<<setw(11)
    <<"First Name"<<left<<setw(10)<<right<<"Balance"<<endl;

    ClientData client;

    inCredit.read(reinterpret_cast<char *>(&client),sizeof(ClientData));

    while(inCredit&&!inCredit.eof())
    {
        if(client.getAccountNumber()!=0)
            outputLine(cout,client);

        inCredit.read(reinterpret_cast<char *>(&client),sizeof(ClientData));

    }

}

void outputLine(ostream &output,const ClientData &record)
{

}
