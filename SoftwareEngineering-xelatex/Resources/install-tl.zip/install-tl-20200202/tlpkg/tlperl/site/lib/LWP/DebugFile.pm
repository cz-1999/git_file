package LWP::DebugFile;

our $VERSION = '6.37';

# legacy stub

1;
