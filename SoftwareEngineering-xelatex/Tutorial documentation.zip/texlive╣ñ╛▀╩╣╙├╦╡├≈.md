**目录**

[TOC]



## TeX Live工具使用说明

### 1.准备工作

#### 1.1.官方网站

texlive官方网站http://tug.org/texlive/

#### 1.2.在线安装TeX Live

​     通过下载 Windows的[install-tl-windows.exe](http://mirror.ctan.org/systems/texlive/tlnet/install-tl-windows.exe)（18mb）或下载zip文件[install-tl.zip](http://mirror.ctan.org/systems/texlive/tlnet/install-tl.zip) （22mb），它与`.exe`作用相同，但是`.zip`归档文件在所有平台上都可以正常运行。同时也可以下载[install-tl-unx.tar.gz](http://mirror.ctan.org/systems/texlive/tlnet/install-tl-unx.tar.gz) （4mb）来开始TeX Live安装。`.tar.gz`比`.zip`要小得多，因为它省略了仅Windows所需的安装支持程序。其实档案是相同的。`Resources`文件夹中已经包含了三个文件，如果无法损坏可以按ctrl并点击链接并重新下载。

​	因为是live安装版，会在安装时进行安装包的下载，完整镜像需要3g左右，请做好相关准备。

#### 1.3.通过下载镜像安装

完整版镜像下载种子可以在`Resources`文件夹中看到，使用迅雷或其他方法进行下载（3.32gb）

装载镜像后双击`install-tl-windows.bat`进行安装，如果你是新手，一律点击下一步就可以了。老手建议用**install-tl-advanced.bat。**

通过镜像安装具体方法请参照https://zhuanlan.zhihu.com/p/64530166。

### 2.开始使用

#### 2.1.文件夹目录说明

> 河南工业大学-xelatex
>
> > Resources `存放安装包`
> >
> > > install-tl-windows.exe   
> > >
> > > install-tl.zip									
> > >
> > > install-tl-unx.tar.gz
> > >
> > > texlive2019-20190410.iso.torrent    `完整iso安装包种子`
> >
> > report     `存放letex文件模板`
> >
> > > haut.png	 `校标`
> > >
> > > report.tex	`要修改的tex文件`
> > >
> > > report.toc	`类似于头文件，不需要修改`
> >
> > texlive工具使用说明.pdf
> >
> > Tutorial documentation.zip  `教程文档源文件存放`

#### 2.2.编辑tex文件

##### 2.2.1.打开report.tex文件

![](images\mulu.png)

打开后的样子

![](images\texmain.png)

##### 2.2.2.修改文件

由于这个tex文件是一个模板，需要大家自己修改，需要修改的位置及作用如下：

**1.修改页眉**

![](images/Header.png)

pdf中示例：

![](images\herdershow.png)

**2.封面设置**

> *注意，只能修改红色框内标注的内容，将其修改为对应的正确内容*

其中`\\`为换行符、`\quad`为空格符，`\qquad`为空两格，**名字只有两个子的请注意增加空格**！！！

在输入`\quad`或`\qquad`命令后需要**添加空格**，否则会编译错误！例如：

`张\quad（在此处加空格）三`



![](images/titlepage.png)

**3.摘要设置**

修改绿色方框内内容来修改摘要页，对应生成效果如图：

![](images/Summmary.png)

**4.编写实验目的**

修改绿色方框内内容来修改摘要页，对应生成效果如图：

![](images/mudi.png)

**注意：使用`\item`命令在行之前增加`·`符号**

**5.在报告中添加公式**

如果需要增加公式则参照如下格式进行修改：

对应代码部分在示例1

![](images/gongshi.png)

**6.在报告中添加代码**

对应代码部分在示例2

修改绿色方框内内容来修改摘要页，对应生成效果如图：

![](images/daima.png)

**注意：修改绿色方框首行`language=python`内容来确定你使用的语言。**

**6.添加总结**

对应代码部分在实验总结

修改绿色方框内内容来修改摘要页，对应生成效果如图：

![](images/zongjie.png)

**7.附录设置以及表格设置**

对应代码部分在代码及表格设置

修改绿色方框内内容来修改摘要页，对应生成效果如图：

![](images/fulu.png)

**8.添加单栏或双栏图片**

插入图片时只需要将图片放进report文件夹中，并修改下方代码即可。

```latex
\section{插入图片示例}
\begin{flushleft}%左对齐格式
    \includegraphics[width=0.4\textwidth]{haut.png}\\  %在左侧插图
\end{flushleft}
\begin{flushright}%右对齐格式
    \includegraphics[width=0.4\textwidth]{haut.png}\\  %在右侧插图
\end{flushright}
\begin{center}%居中格式
    \includegraphics[width=0.4\textwidth]{haut.png}\\  %在中间插图
\end{center}
\begin{center}%居中格式
    \includegraphics[width=0.4\textwidth]{leftpicture.png} %左边的图
    \includegraphics[width=0.4\textwidth]{rightpicture.png}\\  %右边的图
\end{center}

```

对以上代码的解释：

`\includegraphics[width=0.4\textwidth]{haut.png}`中`width=0.4`为图片宽度，后面花括号`{}`中的`haut.png`是图片的名称

在双栏图片中，width必须小于**0.50**否则图片会偏移到下一行。

![](images/tp.png)

#### 2.3.编译并输出

在编译器的左上角有一个下拉菜单，菜单是用来选择不同的编译方式的，在这里选择`XeLaTeX`

![](images/caidan.png)

选择正确后按下绿色编译按钮（下拉菜单左侧），在编译器最下方会多出一个控制台显示当前编译进程。

![](images/bianyir.png)

如果出现语法错误则会在最下方出现错误原因以及`？`符号。

![](images/bianyiw.png)

这里的错误是我在第258行少添加一个`\end`

**编译成功后，生成的pdf会弹出预览。**

**注意**：目录部分必须编译两次，否则不会显示目录！

![](images/1.png)

第一次编译后目录部分为空，此时进行第二次编译：

![](images/2.png)

可以看到目录被成功显示。

在**编译成功**后，`report`文件夹中会多出很多文件，`report.pdf`是生成后的文件，可以单独拷贝使用了。

![](images/report.png)

### 3.模板复用

模板复用有两种方法：

第一，重新下载模板并修改；

第二，删除`report`文件夹中的部分文件，只留下如下三个文件，对`.tex`文件重新编辑即可。

![](images/liu.png)

